Pizza Generator

List any issues, Chat GPT experiences, other people you may have worked
with, or any other information that seems relevant about this assignment

----------------


