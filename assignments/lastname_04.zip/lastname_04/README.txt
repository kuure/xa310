Explain how BOTH algorithms work below, using your own language 
and / or pseudocode as needed...

---
