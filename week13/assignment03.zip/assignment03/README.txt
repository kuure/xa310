1) How much did any sort of AI play into your work? It's allowable so
please be honest. How much work did you have to do to write and modify
prompts to get the results you were looking for?


2) Please explain how both the non-recursive and recursive algorithms work,
using your own words (not an AI, please)



