Assignment 04 - Sorting Algorithms
----------------------------------


The countingSort.html file includes an example of that algorithm implemented in JavaScript

In the sortingAlgorithm.html file, implement your chosen algorithm using JavaScript. 

In this file, add your explanations and pseudocode:

----



