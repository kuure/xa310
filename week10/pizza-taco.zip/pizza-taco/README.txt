Pizza / Taco

This HTML document will work as a starting point.

Make sure each person has a copy of it. 

Please list who you partnered with below:

