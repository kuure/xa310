const people = [

{
	firstName: "Jeff",
	lastName: "Kuure",
	year: "Way Graduated",
	age: 50,
	siblings: true,
	pets: true,
	favoriteColor: "black"
},

{
	firstName: "Peyton",
	lastName: "Johnson",
	year: null,
	age: 19,
	siblings: true,
	pets: true,
	favoriteColor: "Blue"
},

{
	firstName: "Hannah",
	lastName: "VanLoo",
	year: "junior",
	age: 20,
	siblings: true,
	pets: true,
	favoriteColor: "green",
},

{
	firstName: "Jacob",
	lastName: "Roginski",
	year: "Sophomore",
	age: 19,
	siblings: true,
	pets: false,
	favoriteColor: "Green",
},

{
	firstName: "Maren",
	lastName: "O’Connor",
	year: "Junior",
	age: 20,
	siblings: true,
	pets: false,
	favoriteColor: "Purple"
},

{
	firstName: "Ipek",
	lastName: "Bayik",
	year: "Junior",
	age: 21,
	siblings: true,
	pets: true,
	favoriteColor: "Purple"
},

{
	firstName:"Yaowen",
	lastname:"Cui",
	year:2025,
	age:22,
	Siblings:true,
	pets:false,
	favoriteColor:"Black"
},


{
	firstName: "Zach",
	lastName: "Anderson",
	year: "Junior",
	age: 20,
	siblings: true,
	pets: false,
	favoriteColor: "Green"
},


{
	firstName: "Eden",
	lastName: "Kellman",
	year: "Sophomore",
	age: 19,
	siblings: true,
	Pets: true,
	favoriteColor: "Blue"
},

{
	firstName: "TreShai",
	lastName: "Hubbard",
	year: "Junior",
	age: 20,
	siblings: false,
	pets: true,
	favoriteColor: "yellow",
},

{
	firstName: "Dre",
	LastName: "Holmes",
	favoriteColor: "Green",
	year:2026,
	pet:false,
	siblings:false
},

{
	firstName: "Beiran",
	lastName: "Wu",
	year: "Junior",
	age: 22,
	siblings:true,
	Pets:false,
	favoriteColor: "blue"
},

{
	firstName: "Eric",
	lastName: "Chesney",
	year: "Junior",
	age: 23,
	siblings: true,
	pets: true,
	favoriteColor: "green"
},

{
	firstName: "Alex",
	LastName: "Hadous", 
	Year: 2003,
	Age: 21,
	Siblings: true, 
	Pets: true, 
	FavoriteColor: "green"
},

{
	firstName: "Lucas",
	lastName: "Porco",
	year: 2026,
	age: 22,
	favoriteColor: "Orange",
	pets: false,
	siblings: true
},

{
	firstName: "Nina",
	lastName: "Johnson",
	year: "Junior",
	age: 20,
	siblings: true,
	pets: false,
	favoriteColor: "red",
},

{
	firstName: "Eden",
	lastName: "Kellman",
	year: "Sophomore",
	age: 19,
	siblings: true,
	pets: true,
	favoriteColor: "blue"
},



{
	firstName: "Zoe",
	lastName: "Jiang",
	year: 2026,
	age: 20,
	pets: false,
	favoriteColor: "pink"
},


{
	firstName: "Jacob",
	lastName: "Roginski",
	year: "Sophomore",
	age: 20,
	siblings: true,
	pets: true,
	favoriteColor: "Green"
},


{
	firstName: "Alex",
	lastName: "Hadous",
	year: "Senior",
	age: 21,
	pets: true,
	favoriteColor: "Gray"
},

]
